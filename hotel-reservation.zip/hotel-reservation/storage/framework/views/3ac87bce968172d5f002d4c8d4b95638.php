<?php if (isset($component)) { $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54 = $component; } ?>
<?php $component = App\View\Components\AppLayout::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('app-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(App\View\Components\AppLayout::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
     <?php $__env->slot('header', null, []); ?> 
        <h2 class="font-semibold text-xl text-gray-800 leading-tight">
            Checkout form
        </h2>
     <?php $__env->endSlot(); ?>

    <div class="py-12">

        <div class="container">
            <div class="row justify-content-center">
                <?php if($errors->any()): ?>
                    <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <div class="col-md-4 text-center">
                            <p class="text-danger"><?php echo e($error); ?></p>
                        </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                <?php endif; ?>
                
            </div>
        </div>

        <div class="container">

            <main>

                <div class="row g-5">
                    <div class="col-md-5 col-lg-4 order-md-last">
                        <ul class="list-group mb-3">
                            <li class="list-group-item d-flex justify-content-between lh-sm">
                                <div>
                                    <h6 class="my-0"><?php echo e($room['title']); ?></h6>
                                    <small class="text-body-secondary"><?php echo e($room['descr']); ?></small>
                                </div>
                                <span class="text-body-secondary">Type: <?php echo e($room['type']); ?></span>
                            </li>
                            <li class="list-group-item d-flex justify-content-between lh-sm">
                                <div>
                                <h6 class="my-0">Price</h6>
                                <small class="text-body-secondary">per day</small>
                                </div>
                                <span class="text-body-secondary" id="price">$<?php echo e($room['price']); ?></span>
                            </li>
                        </ul>

                    </div>

                    <div class="col-md-7 col-lg-8">
                        <h4 class="mb-3">Check-in/Check-out</h4>
                        <form method="post" action="<?php echo e(route( 'book', [ 'id'=> $room['id'] ] )); ?>">

                            <?php echo csrf_field(); ?>

                            <div class="row g-3">

                                <div class="col-sm-6">
                                    <label for="checkin" class="form-label">Check-in Date</label>
                                    <input min="<?php echo e(date('Y-m-d')); ?>" type="date" class="form-control" id="checkin" name="checkin" required>
                                </div>

                                <div class="col-sm-6">
                                    <label for="checkout" class="form-label">Check-out Date</label>
                                    <input min="<?php echo e(date('Y-m-d')); ?>" type="date" class="form-control" id="checkout" name="checkout" required>
                                </div>


                                <hr class="my-4">

                                <button class="w-100 btn btn-primary btn-lg" type="submit">Book the room</button>

                            </div>
                            
                        </form>
                    </div>

                </div>

            </main>

        </div>

    </div>

    <script>
        const perDay = <?php echo e($room['price']); ?>

        function calculateDays() {
            var startDate = new Date(document.getElementById("checkin").value);
            var endDate = new Date(document.getElementById("checkout").value);

            // Calculate the time difference in milliseconds
            var timeDiff = endDate.getTime() - startDate.getTime();

            // Convert the time difference to days
            var daysDiff = Math.floor(timeDiff / (1000 * 3600 * 24));

            if( daysDiff > 0 ){
                document.getElementById('price').innerText = '$' + daysDiff*perDay
            }       
        }

        document.getElementById("checkin").addEventListener("input", calculateDays);
        document.getElementById("checkout").addEventListener("input", calculateDays);
  </script>

 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $component = $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?><?php /**PATH D:\xampp\htdocs\web-dev-1\hotel-reservation\resources\views/checkout.blade.php ENDPATH**/ ?>