
<?php if (isset($component)) { $__componentOriginal42b37f006f8ebbe12b66cfa27a5def06 = $component; } ?>
<?php $component = App\View\Components\PublicLayout::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('public-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(App\View\Components\PublicLayout::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>

    <div class="py-12">

        <div class="container mt-5 mb-5">
            
            <div class="row justify-content-center">

                <div class="col-md-6">

                    <div class="card">
                        <img src="<?php echo e(asset( 'images/img.jpg' )); ?>" class="card-img-top" alt="...">
                        <div class="card-body">
                            <h5 class="card-title">Welcome to Hotel Ehsan</h5>
                            <p class="card-text">Have fun with The service and our rooms.</p>
                        </div>
                    </div>

                </div>

            </div>

        </div>
        
    </div>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal42b37f006f8ebbe12b66cfa27a5def06)): ?>
<?php $component = $__componentOriginal42b37f006f8ebbe12b66cfa27a5def06; ?>
<?php unset($__componentOriginal42b37f006f8ebbe12b66cfa27a5def06); ?>
<?php endif; ?><?php /**PATH D:\xampp\htdocs\web-dev-1\hotel-reservation\resources\views/welcome.blade.php ENDPATH**/ ?>