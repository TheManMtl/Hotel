<?php if (isset($component)) { $__componentOriginal42b37f006f8ebbe12b66cfa27a5def06 = $component; } ?>
<?php $component = App\View\Components\PublicLayout::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('public-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(App\View\Components\PublicLayout::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
     <?php $__env->slot('header', null, []); ?> 
        <h2 class="font-semibold text-xl text-gray-800 leading-tight">
            Rooms
        </h2>
     <?php $__env->endSlot(); ?>

    <div class="py-12">
        <div class="container my-5">

            <div class="row row-cols-1 row-cols-sm-2 row-cols-md-3 g-3">

                <?php $__currentLoopData = $list; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $room): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                    <div class="col-md-4">
                        <div class="card shadow h-100">
                            <img class="bd-placeholder-img card-img-top" src="<?php echo e(asset( $room['img'] )); ?>" alt="<?php echo e($room['title']); ?>">
                            <div class="card-body">
                                <p class="card-text"><?php echo e($room['title']); ?></p>
                                <p><?php echo e($room['descr']); ?></p>
                                <small class="badge badge-sm bg-info mb-3">$<?php echo e($room['price']); ?></small>
                                <div class="d-flex justify-content-between align-items-center">
                                    <div class="btn-group">
                                        <a href="<?php echo e(route( 'checkout', [ 'id'=> $room['id'] ] )); ?>" type="button" class="btn btn-sm btn-success shadow">Reserve</a>
                                    </div>
                                    <small class="text-body-secondary"><?php echo e($room['type']); ?></small>
                                </div>
                            </div>
                        </div>
                    </div>

                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            
            </div>

        </div>
    </div>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal42b37f006f8ebbe12b66cfa27a5def06)): ?>
<?php $component = $__componentOriginal42b37f006f8ebbe12b66cfa27a5def06; ?>
<?php unset($__componentOriginal42b37f006f8ebbe12b66cfa27a5def06); ?>
<?php endif; ?><?php /**PATH C:\Users\Davoud Rafati\Desktop\ehsan\hotel-reservation\resources\views/rooms.blade.php ENDPATH**/ ?>