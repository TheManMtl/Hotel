
<x-public-layout>

    <div class="py-12">

        <div class="container mt-5 mb-5">
            
            <div class="row justify-content-center">

                <div class="col-md-6">

                    <div class="card">
                        <img src="{{ asset( 'images/img.jpg' ) }}" class="card-img-top" alt="...">
                        <div class="card-body">
                            <h5 class="card-title">Welcome to Hotel Ehsan</h5>
                            <p class="card-text">Have fun with The service and our rooms.</p>
                        </div>
                    </div>

                </div>

            </div>

        </div>
        
    </div>
</x-public-layout>